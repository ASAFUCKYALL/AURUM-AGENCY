
const ctx = document.getElementById('growthChart');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Mois 1', 'Mois 2', 'Mois 3', 'Mois 4', 'Mois 5', 'Mois 6'],
        datasets: [{
            label: 'Croissance Client (%)',
            data: [20, 45, 80, 120, 150, 187],
            borderColor: '#007BFF',
            backgroundColor: 'rgba(0, 123, 255, 0.3)',
            fill: true,
            tension: 0.4
        }]
    }
});
